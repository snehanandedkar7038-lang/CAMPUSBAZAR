/* ==========================================
   CAMPUSBAZAAR — SCRIPT.JS
   Student-only marketplace
   ========================================== */

// ── STORAGE KEYS ──
const KEYS = {
  USERS:    'cb_users',
  PRODUCTS: 'cb_products',
  CURRENT:  'cb_current_user',
};

// ── STATE ──
let currentUser    = null;
let allProducts    = [];
let activeCategory = 'all';

// ── SAMPLE DATA (seed if empty) ──
const SAMPLE_PRODUCTS = [
  {
    id: 'p1',
    name: 'Casio fx-991ES Plus Calculator',
    category: 'calculator',
    description: 'Scientific calculator in excellent condition. Used for 1 semester only. All functions working perfectly. Comes with original cover.',
    price: 450,
    originalPrice: 1200,
    condition: 'Like New',
    image: null,
    emoji: '🧮',
    sellerPRN: '2021001001',
    sellerName: 'Rohan Mehta',
    postedAt: Date.now() - 86400000 * 2,
  },
  {
    id: 'p2',
    name: 'Engineering Drawing Drafter Set',
    category: 'drafter',
    description: 'Complete drafter set with mini-drafter, compass, set squares (30°/60° and 45°), and drawing board. Good condition, minor scratches on board.',
    price: 800,
    originalPrice: 2500,
    condition: 'Good',
    image: null,
    emoji: '📐',
    sellerPRN: '2021001002',
    sellerName: 'Priya Sharma',
    postedAt: Date.now() - 86400000 * 3,
  },
  {
    id: 'p3',
    name: 'DBMS Handwritten Notes (Sem 5)',
    category: 'notes',
    description: 'Complete DBMS notes from semester 5. Covers ER diagrams, SQL, normalization, transactions. Neat handwriting, all topics covered as per syllabus.',
    price: 120,
    originalPrice: null,
    condition: 'Good',
    image: null,
    emoji: '📒',
    sellerPRN: '2020001003',
    sellerName: 'Anjali Patil',
    postedAt: Date.now() - 86400000 * 1,
  },
  {
    id: 'p4',
    name: 'Fluid Mechanics Textbook (R.K. Bansal)',
    category: 'manual',
    description: 'R.K. Bansal Fluid Mechanics and Hydraulic Machines. Latest edition, minor pencil marks inside. Highly recommended for MECH students.',
    price: 280,
    originalPrice: 680,
    condition: 'Good',
    image: null,
    emoji: '📗',
    sellerPRN: '2021001004',
    sellerName: 'Vikram Joshi',
    postedAt: Date.now() - 86400000 * 5,
  },
  {
    id: 'p5',
    name: 'AutoCAD Student License Notes + Practice Files',
    category: 'notes',
    description: '2D drafting practice sheets and command reference cheat-sheet. Super useful for AutoCAD lab. Printed and spiral-bound.',
    price: 90,
    originalPrice: null,
    condition: 'Like New',
    image: null,
    emoji: '💻',
    sellerPRN: '2020001005',
    sellerName: 'Neha Desai',
    postedAt: Date.now() - 86400000 * 7,
  },
  {
    id: 'p6',
    name: 'Staedtler Geometry Box Set',
    category: 'stationery',
    description: 'Premium Staedtler geometry box with compass, divider, protractor, scale and more. Hardly used, box is intact.',
    price: 180,
    originalPrice: 420,
    condition: 'Like New',
    image: null,
    emoji: '✏️',
    sellerPRN: '2022001006',
    sellerName: 'Aditya Kumar',
    postedAt: Date.now() - 86400000 * 4,
  },
];

// ────────────────────────────────────────
// INIT
// ────────────────────────────────────────
function init() {
  // Seed sample data if no products exist
  const stored = JSON.parse(localStorage.getItem(KEYS.PRODUCTS) || '[]');
  if (stored.length === 0) {
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(SAMPLE_PRODUCTS));
  }

  // Check for logged-in session
  const savedUser = localStorage.getItem(KEYS.CURRENT);
  if (savedUser) {
    currentUser = JSON.parse(savedUser);
    launchApp();
  } else {
    document.getElementById('authScreen').classList.add('active');
  }
}

// ────────────────────────────────────────
// AUTH HELPERS
// ────────────────────────────────────────

/** Validate PRN: exactly 10 digits */
function isValidPRN(prn) {
  return /^\d{10}$/.test(prn.trim());
}

/** Get all users from localStorage */
function getUsers() {
  return JSON.parse(localStorage.getItem(KEYS.USERS) || '[]');
}

/** Save users array */
function saveUsers(users) {
  localStorage.setItem(KEYS.USERS, JSON.stringify(users));
}

/** Switch between Login / Register tabs */
function switchAuthTab(tab) {
  document.getElementById('loginForm').classList.toggle('active', tab === 'login');
  document.getElementById('registerForm').classList.toggle('active', tab === 'register');
  document.getElementById('loginTabBtn').classList.toggle('active', tab === 'login');
  document.getElementById('registerTabBtn').classList.toggle('active', tab === 'register');
  hideError('loginError');
  hideError('registerError');
}

/** Handle Login submission */
function handleLogin(e) {
  e.preventDefault();
  const prn  = document.getElementById('loginPRN').value.trim();
  const pass = document.getElementById('loginPass').value;

  if (!isValidPRN(prn)) {
    showError('loginError', 'PRN must be exactly 10 digits.');
    return;
  }

  const users = getUsers();
  const user  = users.find(u => u.prn === prn && u.password === pass);

  if (!user) {
    showError('loginError', 'Invalid PRN or password. Check your credentials.');
    return;
  }

  currentUser = user;
  localStorage.setItem(KEYS.CURRENT, JSON.stringify(user));
  launchApp();
  showToast('Welcome back, ' + user.name.split(' ')[0] + '! 👋');
}

/** Handle Register submission */
function handleRegister(e) {
  e.preventDefault();
  const name  = document.getElementById('regName').value.trim();
  const prn   = document.getElementById('regPRN').value.trim();
  const email = document.getElementById('regEmail').value.trim();
  const pass  = document.getElementById('regPass').value;

  if (!isValidPRN(prn)) {
    showError('registerError', 'PRN must be exactly 10 digits (numbers only).');
    return;
  }
  if (pass.length < 6) {
    showError('registerError', 'Password must be at least 6 characters.');
    return;
  }

  const users = getUsers();
  if (users.find(u => u.prn === prn)) {
    showError('registerError', 'This PRN is already registered. Please login.');
    return;
  }

  const newUser = { prn, name, email, password: pass, joinedAt: Date.now() };
  users.push(newUser);
  saveUsers(users);

  currentUser = newUser;
  localStorage.setItem(KEYS.CURRENT, JSON.stringify(newUser));
  launchApp();
  showToast('Account created! Welcome, ' + name.split(' ')[0] + ' 🎉');
}

/** Logout */
function handleLogout() {
  if (!confirm('Log out of CampusBazaar?')) return;
  currentUser = null;
  localStorage.removeItem(KEYS.CURRENT);
  document.getElementById('appScreen').classList.remove('active');
  document.getElementById('authScreen').classList.add('active');
  showToast('Logged out. See you soon!');
}

// ────────────────────────────────────────
// APP LAUNCH
// ────────────────────────────────────────
function launchApp() {
  document.getElementById('authScreen').classList.remove('active');
  document.getElementById('appScreen').classList.add('active');

  // Update nav UI
  document.getElementById('navUserName').textContent = currentUser.name.split(' ')[0];
  document.getElementById('userAvatar').textContent  = currentUser.name[0].toUpperCase();

  // Load and render products
  loadProducts();
  renderProducts();
  showView('browse');
}

// ────────────────────────────────────────
// PRODUCTS
// ────────────────────────────────────────

/** Load products from localStorage into state */
function loadProducts() {
  allProducts = JSON.parse(localStorage.getItem(KEYS.PRODUCTS) || '[]');
}

/** Save products array to localStorage */
function saveProducts() {
  localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(allProducts));
}

/** Generate a unique ID */
function uid() {
  return 'p' + Date.now() + Math.random().toString(36).slice(2, 6);
}

// ────────────────────────────────────────
// SELL FORM
// ────────────────────────────────────────
let selectedCondition = 'Like New';
let uploadedImageData = null; // base64 string

function selectCondition(btn) {
  document.querySelectorAll('.cond-pill').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  selectedCondition = btn.dataset.val;
}

function handleImagePreview(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    uploadedImageData = ev.target.result;
    const preview = document.getElementById('imagePreview');
    const placeholder = document.getElementById('uploadPlaceholder');
    preview.src = uploadedImageData;
    preview.style.display = 'block';
    placeholder.style.display = 'none';
  };
  reader.readAsDataURL(file);
}

function handleAddProduct(e) {
  e.preventDefault();
  const name      = document.getElementById('prodName').value.trim();
  const category  = document.getElementById('prodCategory').value;
  const desc      = document.getElementById('prodDesc').value.trim();
  const price     = parseFloat(document.getElementById('prodPrice').value);
  const origPrice = parseFloat(document.getElementById('prodOrigPrice').value) || null;

  if (!category) {
    showError('sellError', 'Please select a category.');
    return;
  }

  const product = {
    id:           uid(),
    name,
    category,
    description:  desc,
    price,
    originalPrice: origPrice,
    condition:    selectedCondition,
    image:        uploadedImageData,
    emoji:        categoryEmoji(category),
    sellerPRN:    currentUser.prn,
    sellerName:   currentUser.name,
    postedAt:     Date.now(),
  };

  loadProducts();
  allProducts.unshift(product); // add to top
  saveProducts();

  // Reset form
  document.getElementById('sellForm').reset();
  uploadedImageData = null;
  document.getElementById('imagePreview').style.display = 'none';
  document.getElementById('uploadPlaceholder').style.display = 'flex';
  document.querySelectorAll('.cond-pill').forEach((p, i) => p.classList.toggle('active', i === 0));
  selectedCondition = 'Like New';
  hideError('sellError');

  showToast('Item listed successfully! 🚀');
  showView('browse');
  renderProducts();
}

/** Map category to emoji fallback */
function categoryEmoji(cat) {
  const map = { calculator:'🧮', drafter:'📐', notes:'📒', manual:'📗', stationery:'✏️', other:'📦' };
  return map[cat] || '📦';
}

// ────────────────────────────────────────
// FILTERING & RENDERING
// ────────────────────────────────────────

function filterByCategory(cat, btn) {
  activeCategory = cat;
  document.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
  btn.classList.add('active');
  filterProducts();
}

function resetFilters() {
  activeCategory = 'all';
  document.getElementById('searchInput').value = '';
  document.querySelectorAll('.cat-pill').forEach((p, i) => p.classList.toggle('active', i === 0));
  filterProducts();
}

function filterProducts() {
  loadProducts();
  const query = document.getElementById('searchInput').value.toLowerCase().trim();
  const sort  = document.getElementById('sortSelect').value;

  let filtered = allProducts.filter(p => {
    const matchCat    = activeCategory === 'all' || p.category === activeCategory;
    const matchSearch = !query ||
      p.name.toLowerCase().includes(query) ||
      p.description.toLowerCase().includes(query) ||
      p.category.toLowerCase().includes(query);
    return matchCat && matchSearch;
  });

  // Sort
  if (sort === 'price_asc')  filtered.sort((a, b) => a.price - b.price);
  if (sort === 'price_desc') filtered.sort((a, b) => b.price - a.price);
  if (sort === 'newest')     filtered.sort((a, b) => b.postedAt - a.postedAt);

  renderGrid(filtered, 'productGrid');

  const count = document.getElementById('resultsCount');
  count.textContent = filtered.length === 0
    ? 'No items found'
    : `${filtered.length} item${filtered.length !== 1 ? 's' : ''} found`;

  document.getElementById('emptyState').style.display = filtered.length === 0 ? 'block' : 'none';
}

function renderProducts() {
  filterProducts();
}

/** Render my listings */
function renderMyListings() {
  loadProducts();
  const mine = allProducts.filter(p => p.sellerPRN === currentUser.prn);
  renderGrid(mine, 'myProductGrid', true);
  document.getElementById('myEmptyState').style.display = mine.length === 0 ? 'block' : 'none';
}

/** Render products into a grid container */
function renderGrid(products, containerId, isOwner = false) {
  const grid = document.getElementById(containerId);
  if (!grid) return;

  if (products.length === 0) {
    grid.innerHTML = '';
    return;
  }

  grid.innerHTML = products.map(p => buildCard(p, isOwner)).join('');
}

/** Build HTML string for a product card */
function buildCard(p, showOwnerBadge = false) {
  const isOwner = p.sellerPRN === currentUser?.prn;
  const imgHtml = p.image
    ? `<img src="${p.image}" alt="${escHtml(p.name)}" />`
    : `<span style="font-size:52px">${p.emoji}</span>`;

  const discount = p.originalPrice
    ? Math.round((1 - p.price / p.originalPrice) * 100)
    : null;

  return `
    <div class="product-card" onclick="openProduct('${p.id}')">
      ${isOwner ? '<span class="own-badge">Mine</span>' : ''}
      <div class="card-img-wrap">${imgHtml}</div>
      <div class="card-body">
        <div class="card-category">${p.category}</div>
        <div class="card-title">${escHtml(p.name)}</div>
        <div class="card-desc">${escHtml(p.description)}</div>
        <div class="card-footer">
          <div class="price-block">
            <span class="price-main">₹${p.price}</span>
            ${p.originalPrice ? `<span class="price-orig">₹${p.originalPrice}</span>` : ''}
          </div>
          <span class="cond-badge cond-${p.condition}">${p.condition}</span>
        </div>
        <div class="card-seller">Seller: ${escHtml(p.sellerName)}</div>
      </div>
    </div>`;
}

// ────────────────────────────────────────
// PRODUCT MODAL
// ────────────────────────────────────────

function openProduct(id) {
  loadProducts();
  const p = allProducts.find(x => x.id === id);
  if (!p) return;

  const isOwner = p.sellerPRN === currentUser?.prn;

  const imgHtml = p.image
    ? `<div class="modal-img"><img src="${p.image}" alt="${escHtml(p.name)}" /></div>`
    : `<div class="modal-img" style="display:flex;align-items:center;justify-content:center;"><span style="font-size:80px">${p.emoji}</span></div>`;

  const discount = p.originalPrice
    ? Math.round((1 - p.price / p.originalPrice) * 100)
    : null;

  const contactSection = isOwner
    ? `<div style="background:rgba(124,92,252,0.1);border:1px solid rgba(124,92,252,0.3);border-radius:10px;padding:14px;color:#9499B0;font-size:14px;text-align:center;">
        This is your own listing.
       </div>`
    : `
      <div class="contact-section">
        <div class="modal-section-label">Seller</div>
        <div class="seller-card">
          <div class="seller-avatar-lg">${p.sellerName[0].toUpperCase()}</div>
          <div class="seller-info">
            <div class="seller-name">${escHtml(p.sellerName)}</div>
            <div class="seller-prn">PRN: ${p.sellerPRN}</div>
          </div>
        </div>
        <div class="contact-actions">
          <button class="btn-contact" onclick="openChat('${p.id}')">💬 Message Seller</button>
          <button class="btn-contact btn-whatsapp" onclick="mockWhatsApp('${escHtml(p.sellerName)}')">📱 WhatsApp</button>
        </div>
        <div class="mock-chat" id="mockChat_${p.id}">
          <div class="chat-header">💬 Chat with ${escHtml(p.sellerName)}</div>
          <div class="chat-messages" id="chatMsgs_${p.id}">
            <div class="chat-msg them">
              <div class="chat-bubble">Hi! Is this still available?</div>
            </div>
            <div class="chat-msg me">
              <div class="chat-bubble">Yes, it's available! When can you pick it up?</div>
            </div>
          </div>
          <div class="chat-input-row">
            <input type="text" id="chatIn_${p.id}" placeholder="Type a message…" onkeydown="if(event.key==='Enter')sendMsg('${p.id}')" />
            <button class="chat-send-btn" onclick="sendMsg('${p.id}')">Send</button>
          </div>
        </div>
      </div>`;

  document.getElementById('modalBody').innerHTML = `
    ${imgHtml}
    <div class="modal-category">${p.category}</div>
    <div class="modal-title">${escHtml(p.name)}</div>
    <div class="modal-price-row">
      <span class="modal-price">₹${p.price}</span>
      ${p.originalPrice ? `<span class="modal-orig-price">₹${p.originalPrice}</span>` : ''}
      ${discount ? `<span class="discount-badge">${discount}% off</span>` : ''}
    </div>
    <div class="modal-meta-grid">
      <div class="meta-item"><div class="meta-label">Condition</div><div class="meta-value">${p.condition}</div></div>
      <div class="meta-item"><div class="meta-label">Category</div><div class="meta-value">${p.category}</div></div>
      <div class="meta-item"><div class="meta-label">Posted</div><div class="meta-value">${timeAgo(p.postedAt)}</div></div>
      <div class="meta-item"><div class="meta-label">Seller PRN</div><div class="meta-value">${p.sellerPRN}</div></div>
    </div>
    <hr class="modal-divider" />
    <div class="modal-section-label">Description</div>
    <div class="modal-desc">${escHtml(p.description)}</div>
    <hr class="modal-divider" />
    ${contactSection}
  `;

  document.getElementById('productModal').classList.add('open');
  document.body.style.overflow = 'hidden';
}

function closeProductModal() {
  document.getElementById('productModal').classList.remove('open');
  document.body.style.overflow = '';
}

function closeModal(e) {
  if (e.target.id === 'productModal') closeProductModal();
}

// ── MOCK CHAT ──
function openChat(productId) {
  const chatEl = document.getElementById('mockChat_' + productId);
  if (chatEl) { chatEl.classList.toggle('open'); }
}

function sendMsg(productId) {
  const input = document.getElementById('chatIn_' + productId);
  const msgs  = document.getElementById('chatMsgs_' + productId);
  const text  = input.value.trim();
  if (!text) return;

  // Add user's message
  const myMsg = document.createElement('div');
  myMsg.className = 'chat-msg me';
  myMsg.innerHTML = `<div class="chat-bubble">${escHtml(text)}</div>`;
  msgs.appendChild(myMsg);
  input.value = '';
  msgs.scrollTop = msgs.scrollHeight;

  // Mock auto-reply after 800ms
  const replies = [
    'Sure! I can meet at the library tomorrow.',
    'Price is negotiable 😊',
    'The condition is exactly as described.',
    'You can pay by UPI. My ID is in the profile.',
    'Yes, it's still available!',
  ];
  setTimeout(() => {
    const reply = document.createElement('div');
    reply.className = 'chat-msg them';
    reply.innerHTML = `<div class="chat-bubble">${replies[Math.floor(Math.random() * replies.length)]}</div>`;
    msgs.appendChild(reply);
    msgs.scrollTop = msgs.scrollHeight;
  }, 800);
}

function mockWhatsApp(name) {
  showToast(`Opening WhatsApp for ${name}… (mock)`);
}

// ────────────────────────────────────────
// VIEW SWITCHING
// ────────────────────────────────────────
function showView(viewName) {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  document.getElementById(viewName + 'View').classList.add('active');

  // Bottom nav active state
  document.querySelectorAll('.bn-btn').forEach(b => b.classList.remove('active'));
  const bnMap = { browse: 'bnBrowse', sell: 'bnSell', mylistings: 'bnMine' };
  if (bnMap[viewName]) document.getElementById(bnMap[viewName]).classList.add('active');

  if (viewName === 'mylistings') renderMyListings();
  if (viewName === 'browse')     renderProducts();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// ────────────────────────────────────────
// UI HELPERS
// ────────────────────────────────────────

/** Show error message element */
function showError(id, msg) {
  const el = document.getElementById(id);
  el.textContent = msg;
  el.classList.add('visible');
  el.style.display = 'block';
}

/** Hide error */
function hideError(id) {
  const el = document.getElementById(id);
  el.classList.remove('visible');
  el.style.display = 'none';
}

/** Toast notification */
function showToast(msg) {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

/** Escape HTML to prevent XSS */
function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

/** Human-readable time ago */
function timeAgo(ts) {
  const diff = Date.now() - ts;
  const mins  = Math.floor(diff / 60000);
  const hours = Math.floor(diff / 3600000);
  const days  = Math.floor(diff / 86400000);
  if (mins < 1)   return 'Just now';
  if (mins < 60)  return `${mins}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}

// ────────────────────────────────────────
// KEYBOARD SHORTCUTS
// ────────────────────────────────────────
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') closeProductModal();
});

// ────────────────────────────────────────
// BOOT
// ────────────────────────────────────────
document.addEventListener('DOMContentLoaded', init);
